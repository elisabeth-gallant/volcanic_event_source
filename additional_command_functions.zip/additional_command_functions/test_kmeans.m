
for k=2:1:510;
    ix = k;
    Dk(ix) = inf;
    waitbar(k/510);
    for n=1:20
        [seg, Ts,~,D, numIter ] =...
            kMeansppSegment(vents(:,1:2)',k,1000);
        if(D<Dk(ix))
            Dk(ix) = D;
            Event_Km{ix} = seg;
        end
    end
end

plot(2:10:500,Dk);