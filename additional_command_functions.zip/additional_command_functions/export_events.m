EventCenter = zeros(length(Events),2);
for k=1:length(Events)
EventCenter(k,:) = Events(k).CenterPoint;
end
writematrix(EventCenter,'YM_Events.csv');
