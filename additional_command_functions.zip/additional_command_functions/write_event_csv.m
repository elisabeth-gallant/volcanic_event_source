function EventTable = write_event_csv(Events,filename)

N = length(Events);

Array = [];
for n=1:N
    Nv = size(Events(n).VentLocation,2);
    for k=1:Nv
        Array = [Array; Events(n).VentLocation(:,k)', n, Events(n).CenterPoint', Events(n).Age];
    end
end

varnames = {'Vent_N', 'Vent_E', 'Event_ID', 'Event_N', 'Event_E', 'Event_Age'};

EventTable = array2table(Array,'VariableNames',varnames);

writetable(EventTable,filename);