DMFile = '../DEMs/pali_aike_utm_hillshade.tif';
DEM = readgeoraster(DMFile);
DEMinfo = geotiffinfo(DMFile);

IMG = flipud(DEM);
IMG(IMG(:)==-9999) = min(IMG(IMG(:)~=-9999));
k=450;
X = linspace(DEMinfo.BoundingBox(1,1),DEMinfo.BoundingBox(2,1),size(DEM,1));
Y = linspace(DEMinfo.BoundingBox(1,2),DEMinfo.BoundingBox(2,2),size(DEM,2));

for n=1:length(Event_Km{n})
close;
figure;
image(X,Y,repmat(double(IMG)/double(max(IMG(:))),[1,1,3]));
set(gca,'ydir','normal'); hold on;
plot(vents(:,1),vents(:,2),'.r')
axis([385000 495000 4215000 4285000])
for k=1:length(Event_Km{n})
plot(Event_Km{n}(k).EndPoints(1,:),Event_Km{n}(k).EndPoints(2,:),'w')
plot(Event_Km{n}(k).CenterPoint(1),Event_Km{n}(k).CenterPoint(2),'ow')
end
savefig(['PaliAike_K=',num2str(length(Event_Km{n})),'.fig']);
end